from flask import Flask, render_template, request, redirect, url_for
import subprocess
import signal
import os

app = Flask(__name__)

# This will store the process ID of the running script
process = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start():
    global process
    if process is None:
        process = subprocess.Popen(['jupyter', 'nbconvert', '--to', 'script', 'project_predict.ipynb', '--execute'])
    return redirect(url_for('index'))

@app.route('/stop', methods=['POST'])
def stop():
    global process
    if process is not None:
        os.kill(process.pid, signal.SIGTERM)
        process = None
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
