#!/usr/bin/env python
# coding: utf-8

# In[1]:


import torch
import torch.nn as nn
import torch.optim as optim
import warnings
warnings.filterwarnings('ignore')


class FaceRecognitionModel(nn.Module):
    def __init__(self):
        super(FaceRecognitionModel, self).__init__()
        self.fc1 = nn.Linear(48 * 48, 256)  # Input size should match your data
        self.fc2 = nn.Linear(256, 2)  # Output size should match the number of classes

    def forward(self, x):
        x = x.view(x.size(0), -1)  # Flatten the input
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Instantiate the model
model = FaceRecognitionModel()


# In[2]:


# Dummy data and labels for demonstration
data = torch.randn(10, 1, 48, 48)  # 10 samples of 1x48x48 images
labels = torch.randint(0, 2, (10,))  # 10 labels for 2 classes

# Define loss function and optimizer
loss_fn = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters())

# Training loop (for demonstration; use your actual training code)
for epoch in range(2):  # Train for 2 epochs
    model.train()  # Set model to training mode
    optimizer.zero_grad()
    output = model(data)
    loss = loss_fn(output, labels)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch+1}, Loss: {loss.item()}")
# Dummy data and labels for demonstration
data = torch.randn(10, 1, 48, 48)  # 10 samples of 1x48x48 images
labels = torch.randint(0, 2, (10,))  # 10 labels for 2 classes

# Define loss function and optimizer
loss_fn = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters())

# Training loop (for demonstration; use your actual training code)
for epoch in range(2):  # Train for 2 epochs
    model.train()  # Set model to training mode
    optimizer.zero_grad()
    output = model(data)
    loss = loss_fn(output, labels)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch+1}, Loss: {loss.item()}")


# In[3]:


model_path = 'classifier.pth'
torch.save(model.state_dict(), model_path)
print(f"Model saved to {model_path}")


# In[4]:


# Define the model architecture
model = FaceRecognitionModel()

# Load the trained model parameters
model.load_state_dict(torch.load(model_path))
model.eval()  # Set the model to evaluation mode


# In[5]:


# Define the model architecture
class FaceRecognitionModel(nn.Module):
    def __init__(self):
        super(FaceRecognitionModel, self).__init__()
        self.fc1 = nn.Linear(48 * 48, 256)  # Input size should match your data
        self.fc2 = nn.Linear(256, 2)  # Output size should match the number of classes

    def forward(self, x):
        x = x.view(x.size(0), -1)  # Flatten the input
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Instantiate the model
model = FaceRecognitionModel()

# Dummy data and labels for demonstration (replace with actual data)
data = torch.randn(10, 1, 48, 48)  # 10 samples of 1x48x48 images
labels = torch.randint(0, 2, (10,))  # 10 labels for 2 classes

# Define loss function and optimizer
loss_fn = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters())

# Training loop (for demonstration; use your actual training code)
for epoch in range(2):  # Train for 2 epochs
    model.train()  # Set model to training mode
    optimizer.zero_grad()
    output = model(data)
    loss = loss_fn(output, labels)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch+1}, Loss: {loss.item()}")

# Save the model
model_path = 'classifier.pth'
torch.save(model.state_dict(), model_path)
print(f"Model saved to {model_path}")

# To load the model later
model = FaceRecognitionModel()
model.load_state_dict(torch.load(model_path))
model.eval()  # Set the model to evaluation mode


# In[6]:


# Define the model architecture
class FaceRecognitionModel(nn.Module):
    def __init__(self):
        super(FaceRecognitionModel, self).__init__()
        self.fc1 = nn.Linear(48 * 48, 256)
        self.fc2 = nn.Linear(256, 2)  # Adjust the number of output classes as needed

    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Instantiate the model and load the saved weights
model = FaceRecognitionModel()
model.load_state_dict(torch.load("classifier.pth"))
model.eval()  # Set the model to evaluation mode


# In[7]:


import cv2
import numpy as np
from torchvision import transforms

# Preprocessing function
preprocess = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((48, 48)),  # Ensure this matches the input size of your model
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

# Load Haar Cascade for face detection
haar_file = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(haar_file)


# In[8]:


import pandas as pd
import os
import warnings
warnings.filterwarnings('ignore')


def update_attendance(student_name, date):
    filename = 'attendance.xlsx'
    
    # Check if the file exists
    if os.path.exists(filename):
        df = pd.read_excel(filename, index_col=0)
    else:
        # Initialize an empty DataFrame with a column for dates
        df = pd.DataFrame(columns=['Date'])
    
    # Update the DataFrame with the current date for the student
    if student_name not in df.index:
        df.loc[student_name] = [date]
    else:
        df.loc[student_name] = [date]  # Update the date for existing student
    
    # Save the updated DataFrame back to the file
    df.to_excel(filename)


# In[ ]:


import cv2
import torch
import torch.nn as nn
import numpy as np
from torchvision import transforms
from datetime import datetime
import pandas as pd
import os

# Define the model architecture
class FaceRecognitionModel(nn.Module):
    def __init__(self):
        super(FaceRecognitionModel, self).__init__()
        self.fc1 = nn.Linear(48 * 48, 256)
        self.fc2 = nn.Linear(256, 2)  # Adjust according to the number of classes

    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Preprocessing function
preprocess = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((48, 48)),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

# Load Haar Cascade for face detection
haar_file = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(haar_file)

# Load the trained model
model = FaceRecognitionModel()
model.load_state_dict(torch.load("classifier.pth"))
model.eval()

# Initialize webcam
webcam = cv2.VideoCapture(0)

# Dictionary mapping model output to student names
student_names = {0: 'Devi', 1: 'Ramya'}

def update_attendance(student_name, date):
    filename = 'attendance.csv'
    
    try:
        # Check if the file exists
        if os.path.exists(filename):
            # Load existing data
            try:
                df = pd.read_csv(filename, index_col=0)
            except Exception as e:
                print(f"Error reading CSV file: {e}")
                print("The file might be corrupted or not in a supported format.")
                return
        else:
            # Initialize an empty DataFrame
            df = pd.DataFrame(columns=['Date'])
        
        # Ensure the DataFrame has a column for dates
        if 'Date' not in df.columns:
            df['Date'] = pd.NaT
        
        # Update the DataFrame with the current date for the student
        if student_name not in df.index:
            df.loc[student_name] = [date]
        else:
            df.loc[student_name, 'Date'] = date
        
        # Save the updated DataFrame back to the file
        df.to_csv(filename)
        print(f"Attendance updated for {student_name} on {date}.")
    except Exception as e:
        print(f"Error updating attendance: {e}")

while True:
    _, im = webcam.read()
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        face = gray[y:y+h, x:x+w]
        face = cv2.resize(face, (48, 48))
        face_tensor = preprocess(face).unsqueeze(0)

        with torch.no_grad():
            output = model(face_tensor)
            predicted_class = output.argmax().item()

        # Get the student's name from the predicted class
        student_name = student_names.get(predicted_class, "Unknown")
        cv2.putText(im, student_name, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.rectangle(im, (x, y), (x+w, y+h), (255, 0, 0), 2)

        # Update attendance
        if student_name != "Unknown":
            date_str = datetime.now().strftime('%Y-%m-%d')
            update_attendance(student_name, date_str)

    cv2.imshow("Face Recognition", im)

    if cv2.waitKey(1) & 0xFF == 27:  # Exit on ESC key
        break

webcam.release()
cv2.destroyAllWindows()


# In[ ]:





# In[ ]:




